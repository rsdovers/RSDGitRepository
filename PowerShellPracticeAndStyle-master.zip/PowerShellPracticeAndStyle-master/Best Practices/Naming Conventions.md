TODO: Copy #36 Capitalization guidelines
TODO: Copy #23 Command Prefixes