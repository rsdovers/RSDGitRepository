These documents are in an extremely rough state, not suitable for inclusion in the main guide yet.

<!-- MarkdownTOC depth=4 autolink=true bracket=round -->

- [Include Help](#include-help)

<!-- /MarkdownTOC -->




### Include Help

Discuss: Add a blank line between comment based help and function declaration?
Discuss: Minimum acceptable comment based help: Synopsis, Parameters, and an example for each parameter set (plus pipeline examples if you can contrive one)

TODO: Style guide for MAML help?

